// foobar/goodbye/cookie.test.ts
import { bake } from "./cookie";

test("bakes a cookie", () => expect(bake("oatmeal")).toBe("🍪 oatmeal cookie"));
