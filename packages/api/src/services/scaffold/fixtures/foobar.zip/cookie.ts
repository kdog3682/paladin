// foobar/goodbye/cookie.ts
export const bake = (flavor: string): string => `🍪 ${flavor} cookie`;
