// foobar/goodbye/cookie.demo.ts
import { bake } from "./cookie";

console.log(bake("chocolate chip"));
