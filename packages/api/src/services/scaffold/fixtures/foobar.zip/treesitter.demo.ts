// @foobar/hello/treesitter.demo.ts
import Parser from "tree-sitter";
import TypeScript from "tree-sitter-typescript";

const parser = new Parser();
parser.setLanguage(TypeScript.typescript);

const source = `const greeting: string = "hello, foobar";`;
const tree = parser.parse(source);

console.log(tree.rootNode.toString());
